 //Sign in//
        
        
 $(document).ready(function(){
  $("#myBtn5").click(function(){
    $("#myModal").modal();
  });
});


            //Sign up
$(document).ready(function(){
  $("#myBtn6").click(function(){
    $("#modal-signup").modal();
  });
});



$(document).ready(function(){
  $("#Change_Modal").click(function(){
    $("#modal-signup").modal();
    $("#myModal").modal('hide');
    
  })
})



//  extra

var main = function () {
  $('.push-bar').on('click', function(event){
    if (!isClicked){
      event.preventDefault();
      $('.arrow').trigger('click');
      isClicked = true;
    }
  });

  $('.arrow').css({
    'animation': 'bounce 2s infinite'
  });
  $('.arrow').on("mouseenter", function(){
      $('.arrow').css({
              'animation': '',
              'transform': 'rotate(180deg)',
              'background-color': 'black'
         });
  });
   $('.arrow').on("mouseleave", function(){
      if (!isClicked){
          $('.arrow').css({
                  'transform': 'rotate(0deg)',
                  'background-color': 'black'
             });
      }
  });

  var isClicked = false;

  $('.arrow').on("click", function(){
      if (!isClicked){
          isClicked = true;
          $('.arrow').css({
              'transform': 'rotate(180deg)',
              'background-color': 'black',
         });

          $('.bar-cont').animate({
              top: "-15px"
          }, 300);
          $('.main-cont').animate({
              top: "0px"
          }, 300);
          // $('.news-block').css({'border': '0'});
          // $('.underlay').slideDown(1000);

      }
      else if (isClicked){
          isClicked = false;
          $('.arrow').css({
              'transform': 'rotate(0deg)',       'background-color': 'black'
         });

          $('.bar-cont').animate({
              top: "-215px"
          }, 300);
          $('.main-cont').animate({
              top: "-215px"
          }, 300);
      }
  console.log('isClicked= '+isClicked);
  });

  $('.card').on('mouseenter', function() {
    $(this).find('.card-text').slideDown(300);
  });

  $('.card').on('mouseleave', function(event) {
     $(this).find('.card-text').css({
       'display': 'none'
     });
   });
};

$(document).ready(main);


// gallery cards

        // $('.portfolio-item').isotope({
        //  	itemSelector: '.item',
        //  	layoutMode: 'fitRows'
        //  });
        $('.portfolio-menu ul li').click(function(){
          $('.portfolio-menu ul li').removeClass('active');
          $(this).addClass('active');
          
          var selector = $(this).attr('data-filter');
          $('.portfolio-item').isotope({
            filter:selector
          });
          return  false;
        });
        $(document).ready(function() {
        var popup_btn = $('.popup-btn');
        popup_btn.magnificPopup({
        type : 'image',
        gallery : {
          enabled : true
        }
        });
        });

        // top arrow
        
        var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function () { scrollFunction() };

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {

  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}

